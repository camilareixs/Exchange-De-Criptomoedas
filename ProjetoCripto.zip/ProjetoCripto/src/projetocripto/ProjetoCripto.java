/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package projetocripto;

import view.janelaLogin;

/**
 * 01/05/2024
 * @author camilareixs
 */
public class ProjetoCripto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        janelaLogin login = new janelaLogin();
        login.setVisible(true);
        
        
    }
    
}
